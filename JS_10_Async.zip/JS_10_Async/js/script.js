// window.setTimeout(() => {
//     alert("hello timer");

// }, 3000);

// let i = 0;
// let interval = setInterval(() => { 
//     console.log(i++) 
// }, 1000);

// setTimeout(() => { 
//     clearInterval(interval) 
// }, 5000);


// Client (inddex.html/css + script.js) -> Server (backend: php, python, asp.net) -> DataBase (SQL, MySql) -> Server -> Client

setTimeout(() => {
    console.log("Client: giv me users list...");

    setTimeout(() => {
        console.log("Server: OK. Request data in database...");

        setTimeout(() => {
            console.log("DB: Select * from users and send to server back..");

            setTimeout(() => {
                console.log("Server: Got. Transform. Send to client back....");

                setTimeout(() => {
                    console.log("Client: Got. Show data on page...");
                }, 1000);
            }, 500);
        }, 500);
    }, 1000);
}, 1000);