let ID = 1;
let users = [];
let localUsers = [];
let blocks;
let save = document.getElementById("arrow");
let btn = document.getElementById("btn").onclick = function (event) {
    blocks = document.getElementsByClassName("block1");
    for (let i = 0; i < blocks.length; i++) {
        event.preventDefault();
        blocks[i].classList.toggle("block1");
        blocks[i++].classList.toggle("block1");
    }
}

function Function1(event) {
    event.preventDefault();
    if (blocks[i].classList.contains("block1") == false) {
        // users = [{ id: ID++, name: "Iryna", email: "irynamertsalova@gmail.com", login: "mertsalovaa", password: "1111" }];

        var Name = document.getElementById("name").value;
        let Email = document.querySelector("input[type='email'").value;
        let Login = document.getElementById("login").value;
        var Password = document.querySelector("input[type='password'").value;

        let user = {
            id: ID++,
            name: Name,
            email: Email,
            login: Login,
            password: Password
        };
        users.push(user);
        console.log(user);
        localStorage.setItem("users", JSON.stringify(users));
    }
    else {
        localUsers = users;
        for (let i = 0; i < localUsers.length; i++) {
            if (localUsers[i].name == document.getElementById("name").value && localUsers[i].password == document.querySelector("input[type='password'").value) {
                event.preventDefault();
                console.log(document.querySelector(Name + " " + Password));
                location.href = "mainWindow.html";
            }
            else {
                alert(`Your user ${Name} isn't in this system.\n Please, click on button -> Register <- and register your user`)
            }
        }
        localStorage.setItem("users", JSON.stringify(users));
    }
}