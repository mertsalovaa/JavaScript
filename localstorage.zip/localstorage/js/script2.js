window.onload = () => {
    let data = localStorage.getItem("users");
    if (data != null) {
        ID = users.length;
        users = JSON.parse(data);
    }
}